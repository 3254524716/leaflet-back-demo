create function st_intersects(geography, geography) returns boolean
    immutable
    parallel safe
    language sql
as
$$
SELECT $1 OPERATOR(public.&&) $2 AND public.ST_Distance($1, $2, false) < 0.00001
$$;

alter function st_intersects(geography, geography) owner to postgres;

