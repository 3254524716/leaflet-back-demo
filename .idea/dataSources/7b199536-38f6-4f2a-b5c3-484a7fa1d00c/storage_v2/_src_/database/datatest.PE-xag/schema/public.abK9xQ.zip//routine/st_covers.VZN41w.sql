create function st_covers(geog1 geography, geog2 geography) returns boolean
    immutable
    parallel safe
    language sql
as
$$
SELECT $1 OPERATOR(public.&&) $2 AND public._ST_Covers($1, $2)
$$;

alter function st_covers(geography, geography) owner to postgres;

