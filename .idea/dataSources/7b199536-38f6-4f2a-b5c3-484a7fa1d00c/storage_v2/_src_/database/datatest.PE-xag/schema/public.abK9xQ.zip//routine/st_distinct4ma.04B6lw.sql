create function st_distinct4ma(value double precision[], pos integer[], VARIADIC userargs text[] DEFAULT NULL::text[]) returns double precision
    immutable
    parallel safe
    language sql
as
$$
SELECT COUNT(DISTINCT unnest)::double precision FROM unnest($1)
$$;

comment on function st_distinct4ma(double precision[], integer[], text[]) is 'args: value, pos, VARIADIC userargs - Raster processing function that calculates the number of unique pixel values in a neighborhood.';

alter function st_distinct4ma(double precision[], integer[], text[]) owner to postgres;

