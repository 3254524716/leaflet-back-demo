create function st_within(geom1 geometry, geom2 geometry) returns boolean
    immutable
    parallel safe
    language sql
as
$$
SELECT $2 OPERATOR(public.~) $1 AND public._ST_Contains($2,$1)
$$;

alter function st_within(geometry, geometry) owner to postgres;

