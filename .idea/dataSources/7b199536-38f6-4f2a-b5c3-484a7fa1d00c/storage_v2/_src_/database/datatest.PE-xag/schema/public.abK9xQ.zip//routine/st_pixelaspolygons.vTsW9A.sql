create function st_pixelaspolygons(rast raster, band integer DEFAULT 1, exclude_nodata_value boolean DEFAULT true)
    returns TABLE(geom geometry, val double precision, x integer, y integer)
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT geom, val, x, y FROM public._ST_pixelaspolygons($1, $2, NULL, NULL, $3)
$$;

comment on function st_pixelaspolygons(raster, integer, boolean) is 'args: rast, band=1, exclude_nodata_value=TRUE - Returns the polygon geometry that bounds every pixel of a raster band along with the value, the X and the Y raster coordinates of each pixel.';

alter function st_pixelaspolygons(raster, integer, boolean) owner to postgres;

