create function st_bandmetadata(rast raster, band integer DEFAULT 1)
    returns TABLE(pixeltype text, nodatavalue double precision, isoutdb boolean, path text, outdbbandnum integer, filesize bigint, filetimestamp bigint)
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT pixeltype, nodatavalue, isoutdb, path, outdbbandnum, filesize, filetimestamp FROM public.ST_BandMetaData($1, ARRAY[$2]::int[]) LIMIT 1
$$;

comment on function st_bandmetadata(raster, integer) is 'args: rast, band=1 - Returns basic meta data for a specific raster band. band num 1 is assumed if none-specified.';

alter function st_bandmetadata(raster, integer) owner to postgres;

