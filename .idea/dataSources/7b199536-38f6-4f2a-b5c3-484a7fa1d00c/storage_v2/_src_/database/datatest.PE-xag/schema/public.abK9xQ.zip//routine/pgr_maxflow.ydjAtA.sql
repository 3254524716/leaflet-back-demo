create function pgr_maxflow(text, text) returns bigint
    strict
    language sql
as
$$
SELECT flow
        FROM _pgr_maxflow(_pgr_get_statement($1), _pgr_get_statement($2), algorithm := 1, only_flow := true);
$$;

comment on function pgr_maxflow(text, text) is 'pgr_maxFlow(Combinations)
- Directed graph
- Parameters:
  - Edges SQL with columns: id, source, target, capacity [,reverse_capacity]
  - Combinations SQL with columns: source, target
- Documentation:
  - https://docs.pgrouting.org/latest/en/pgr_maxFlow.html
';

alter function pgr_maxflow(text, text) owner to postgres;

