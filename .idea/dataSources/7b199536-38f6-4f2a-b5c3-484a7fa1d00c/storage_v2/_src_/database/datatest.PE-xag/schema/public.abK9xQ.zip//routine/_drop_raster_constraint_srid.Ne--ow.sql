create function _drop_raster_constraint_srid(rastschema name, rasttable name, rastcolumn name) returns boolean
    strict
    language sql
as
$$
SELECT  public._drop_raster_constraint($1, $2, 'enforce_srid_' || $3)
$$;

alter function _drop_raster_constraint_srid(name, name, name) owner to postgres;

